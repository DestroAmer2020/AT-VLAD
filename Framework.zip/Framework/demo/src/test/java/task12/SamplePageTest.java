package task12;

public class SamplePageTest {
}
