package test.java.task16;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.Assert;
import org.junit.Test;

public class TrelloApiTests {

    private final String apiKey = "your_api_key";
    private final String apiToken = "your_api_token";
    private final String listId = "your_list_id";

    @Test
    public void createCardTest() {
        // Setup request body
        CreateCardRequest request = new CreateCardRequest("Test Card", listId, apiKey, apiToken);

        // Send POST request to create a card
        Response response = RestAssured.given()
                .contentType(ContentType.JSON)
                .body(request)
                .when()
                .post("https://api.trello.com/1/cards");

        // Validate response status code
        Assert.assertEquals(200, response.getStatusCode());

        // Convert response to CreateCardResponse object
        CreateCardResponse actualResponse = response.as(CreateCardResponse.class);

        // Create expected response object
        CreateCardResponse expectedResponse = new CreateCardResponse();
        expectedResponse.setName("Test Card");
        expectedResponse.setId("expected_card_id");
        expectedResponse.setIdList(listId);

        // Validate the response using the custom comparator
        CustomComparator comparator = new CustomComparator();
        Assert.assertTrue(comparator.compare(expectedResponse, actualResponse));
    }
}