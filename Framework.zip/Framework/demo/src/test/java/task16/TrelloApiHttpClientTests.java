package test.java.task16;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.entity.StringEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.junit.Assert;
import org.junit.Test;

public class TrelloApiHttpClientTests {

    private final String apiKey = "your_api_key";
    private final String apiToken = "your_api_token";

    @Test
    public void createBoardTestHttpClient() throws Exception {
        // Create HttpClient
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            // Create the request
            HttpPost httpPost = new HttpPost("https://api.trello.com/1/boards?name=Test%20Board&key=" + apiKey + "&token=" + apiToken);
            StringEntity entity = new StringEntity("{\"name\":\"Test Board\"}");
            httpPost.setEntity(entity);

            // Send the request
            HttpResponse response = httpClient.execute(httpPost);
            String responseBody = EntityUtils.toString(response.getEntity());

            // Validate the response
            Assert.assertEquals(200, response.getStatusLine().getStatusCode());
            // You can parse the responseBody here and compare it as needed
        }
    }
}