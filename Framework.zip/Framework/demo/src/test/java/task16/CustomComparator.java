package test.java.task16;

import java.util.Objects;

public class CustomComparator {
    public boolean compare(CreateBoardResponse expected, CreateBoardResponse actual) {
        return expected != null && actual != null
                && Objects.equals(expected.getId(), actual.getId())
                && Objects.equals(expected.getName(), actual.getName())
                && Objects.equals(expected.getUrl(), actual.getUrl());
    }

    public boolean compare(CreateCardResponse expected, CreateCardResponse actual) {
        return expected != null && actual != null
                && Objects.equals(expected.getId(), actual.getId())
                && Objects.equals(expected.getName(), actual.getName())
                && Objects.equals(expected.getIdList(), actual.getIdList());
    }
}
