package test.java.Request.task16;

public class CreateBoardRequest {
    private String name;
    private String key;
    private String token;

    // Constructor
    public CreateBoardRequest(String name, String key, String token) {
        this.name = name;
        this.key = key;
        this.token = token;
    }

    // Getters and Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getKey() { return key; }
    public void setKey(String key) { this.key = key; }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
}