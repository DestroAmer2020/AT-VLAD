CREATE TABLE address (
    id INT AUTO_INCREMENT PRIMARY KEY,
    street VARCHAR(255),
    city VARCHAR(255),
    state VARCHAR(255)
);

CREATE TABLE person (
    id INT AUTO_INCREMENT PRIMARY KEY,
    isEmployed BOOLEAN,
    name VARCHAR(255),
    address_id INT,
    FOREIGN KEY (address_id) REFERENCES address(id)
);