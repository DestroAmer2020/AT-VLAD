package task10;

import org.testng.annotations.AfterMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class DemoQATest {

    WebDriver driver;

    @BeforeMethod
    public void setUp() {
        // 1. Set up ChromeDriver using DriverManager
        WebDriverManager.chromedriver().setup();  // Automatically sets up the correct ChromeDriver
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless"); // Optional: run without UI
        driver = new ChromeDriver(options);
    }

    @Test
    public void testButtons() {
        // 3. Navigate to the page assigned to your variant (https://demoqa.com)
        driver.get("https://demoqa.com/buttons");

        // 4. Select any three different elements (buttons in this case)
        WebElement doubleClickButton = driver.findElement(By.id("doubleClickBtn"));
        WebElement rightClickButton = driver.findElement(By.id("rightClickBtn"));
        WebElement clickMeButton = driver.findElement(By.xpath("//button[text()='Click Me']"));

        // 5. Interact with all the selected elements
        // Double click on the 'Double Click Me' button
        doubleClickButton.click();

        // Right click on the 'Right Click Me' button
        rightClickButton.click();

        // Click on the 'Click Me' button
        clickMeButton.click();

        // 6. Verify the visibility of each element using assertions
        Assert.assertTrue(doubleClickButton.isDisplayed(), "Double Click Button is not visible");
        Assert.assertTrue(rightClickButton.isDisplayed(), "Right Click Button is not visible");
        Assert.assertTrue(clickMeButton.isDisplayed(), "Click Me Button is not visible");

        // 7. Wrap all these steps into a TestNG test case (already done in the @Test method)
    }

    @AfterMethod
    public void tearDown() {
        // Close the browser after test execution
        if (driver != null) {
            driver.quit();
        }
    }
}