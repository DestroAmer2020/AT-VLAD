package task7;

import task7.Address;
import task7.Person;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class OneToOneTest {

    public static void main(String[] args) {
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        Session session = sessionFactory.getCurrentSession();

        try {
            Transaction transaction = session.beginTransaction();

            Address address = new Address("123 Main St", "New York", "NY");
            Person person = new Person(true, "Alice", address);

            session.save(person); // Saves both person and address due to CascadeType.ALL

            transaction.commit();
            System.out.println("OneToOne relationship test successful!");

        } finally {
            sessionFactory.close();
        }
    }
}