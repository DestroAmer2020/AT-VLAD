package task7;

import task7.Address;
import task7.Person;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.Arrays;
import java.util.Set;

public class OneToManyTest {

    public static void main(String[] args) {
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        Session session = sessionFactory.getCurrentSession();

        try {
            Transaction transaction = session.beginTransaction();

            Address address1 = new Address("456 Oak St", "Boston", "MA");
            Address address2 = new Address("789 Pine St", "Chicago", "IL");
            @SuppressWarnings("unchecked")
            Person person = new Person(true, "Bob", (Set<Address>) Arrays.asList(address1, address2));

            session.save(person); // Saves both person and addresses due to CascadeType.ALL

            transaction.commit();
            System.out.println("OneToMany relationship test successful!");

        } finally {
            sessionFactory.close();
        }
    }
}