package task7;

import task7.Address;
import task7.Person;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.HashSet;
import java.util.Set;

public class ManyToManyTest {

    public static void main(String[] args) {
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        Session session = sessionFactory.getCurrentSession();

        try {
            Transaction transaction = session.beginTransaction();

            Address address1 = new Address("101 Maple St", "San Francisco", "CA");
            Address address2 = new Address("202 Birch St", "Seattle", "WA");

            Set<Address> addresses = new HashSet<>();
            addresses.add(address1);
            addresses.add(address2);

            Person person = new Person(false, "Charlie", addresses);
            session.save(person); // Saves both person and addresses due to CascadeType.ALL

            transaction.commit();
            System.out.println("ManyToMany relationship test successful!");

        } finally {
            sessionFactory.close();
        }
    }
}