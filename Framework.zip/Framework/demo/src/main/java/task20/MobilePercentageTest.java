package task20;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class MobilePercentageTest {

    private AndroidDriver<MobileElement> driver;

    @SuppressWarnings("deprecation")
    @BeforeClass
    public void setup() throws MalformedURLException {
        // Налаштування DesiredCapabilities
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("platformName", "Android");
        caps.setCapability("platformVersion", "11.0"); // версія вашого пристрою
        caps.setCapability("deviceName", "Android Emulator"); // або ім'я вашого реального пристрою
        caps.setCapability("automationName", "UiAutomator2");
        caps.setCapability("appPackage", "com.calculator"); // пакет вашого додатка
        caps.setCapability("appActivity", "com.calculator.CalculatorActivity"); // активність додатка
        // Ініціалізація драйвера Appium
        driver = new AndroidDriver<>(new URL("new URL(\"http://127.0.0.1:4726/wd/hub"), caps);
    }

    @Test
    public void testPercentageOperation() throws IOException {
        // 1. Перехід до калькулятора
        MobileElement calculatorButton = driver.findElement(By.id("com.calculator:id/calculator_button"));
        calculatorButton.click();

        // 2. Введення числа
        MobileElement numberInput = driver.findElement(By.id("com.calculator:id/number_input"));
        numberInput.sendKeys("500");

        // 3. Натискання кнопки відсотка
        MobileElement percentButton = driver.findElement(By.id("com.calculator:id/percent_button"));
        percentButton.click();

        // 4. Перевірка результату
        MobileElement resultText = driver.findElement(By.id("com.calculator:id/result"));
        String result = resultText.getText();

        // Перевірка очікуваного результату
        Assert.assertEquals(result, "100", result);

        // 5. Збереження скріншоту
        final File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(screenshot, new File("screenshot.png"));

        // Збереження DOM (за бажанням)
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("com.calculator:id/result")));
        String domSource = driver.getPageSource();
        FileUtils.writeStringToFile(new File("dom_source.xml"), domSource, "UTF-8");
    }

    @AfterClass
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }
}