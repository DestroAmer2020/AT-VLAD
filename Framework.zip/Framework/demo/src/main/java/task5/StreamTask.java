package task5;

import java.util.*;
import java.util.stream.Collectors;

public class StreamTask {
    public static void main(String[] args) {
        int numberOfElements = args.length > 0 ? Integer.parseInt(args[0]) : 10;

        // Generate random objects
        List<Person> persons = new ArrayList<>();
        for (int i = 0; i < numberOfElements; i++) {
            persons.add(new Person(
                i % 2 == 0,
                "Name" + i,
                new Person.Address("Street" + i, "City" + (i % 3), "State" + (i % 2))
            ));
        }

        // Sort by name and city
        List<Person> sortedPersons = persons.stream()
            .sorted(Comparator.comparing(Person::getName)
                              .thenComparing(p -> p.getAddress().getCity()))
            .collect(Collectors.toList());

        // Filter by isEmployed and state
        List<Person> filteredPersons = persons.stream()
            .filter(p -> p.isEmployed() && "State0".equals(p.getAddress().getState()))
            .collect(Collectors.toList());

        // Collect main fields (e.g., name)
        List<String> names = persons.stream()
            .map(Person::getName)
            .collect(Collectors.toList());

        // Print results
        System.out.println("Sorted Persons: " + sortedPersons);
        System.out.println("Filtered Persons: " + filteredPersons);
        System.out.println("Names: " + names);
    }
}