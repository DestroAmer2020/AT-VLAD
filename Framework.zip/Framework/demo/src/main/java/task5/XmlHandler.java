package task5;

import java.io.File;

public class XmlHandler {
    public static void main(final String[] args) throws Exception {
        final JAXBContext context = JAXBContext.newInstance(Person.class);

        // Deserialize XML from input.xml
        final Unmarshaller unmarshaller = context.createUnmarshaller();
        final Person person = (Person) unmarshaller.unmarshal(new File("input.xml"));

        // Modify fields
        person.setName("John Doe");
        person.getAddress().setCity("New York");

        // Serialize to output.xml
        final task5.Unmarshaller marshaller = context.createUnmarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshaller.marshal(person, new File("output.xml"));

        System.out.println("XML processing completed.");
    }
}