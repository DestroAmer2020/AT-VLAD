package task5;

import java.io.File;
import java.security.Permission;

public class JsonHandler {
    public static void main(String[] args) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();

        // Deserialize JSON from input.json
        final Permission person = objectMapper.readValue(new File("input.json"), Person.class);

        // Modify fields
        ((Object) person).setName("John Doe");
        person.getClass().setCity("New York");

        // Serialize to output.json
        objectMapper.writeValue(new File("output.json"), person);

        System.out.println("JSON processing completed.");
    }
}