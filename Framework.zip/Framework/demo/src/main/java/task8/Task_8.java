package task8;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

public class Task_8 {

    private final Task2 task2 = new Task2();

    // Тест 1: Тестування ініціалізації масиву
    @Test
    public void testInitializeArray() {
        int[] expected = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        assertEquals(task2.initializeArray(), expected, "initializeArray method failed");
    }

    // Тест 2: Тестування підрахунку парних чисел
    @Test(dataProvider = "evenNumbersProvider")
    public void testCountEvenNumbers(int[] array, int expectedCount) {
        assertEquals(task2.countOddNumbers(array), expectedCount, "countEvenNumbers method failed");
    }

    @DataProvider(name = "evenNumbersProvider")
    public Object[][] provideEvenNumbers() {
        return new Object[][]{
                {new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}, 5},
                {new int[]{2, 4, 6, 8}, 4},
                {new int[]{1, 3, 5, 7}, 0}
        };
    }

    // Тест 3: Тестування суми чисел у масиві з параметром із testng.xml
    @Test
    @Parameters({"expectedSum"})
    public void testSumArrayWithParameters(int expectedSum) {
        int[] array = task2.initializeArray();
        assertEquals(task2.sumArray(array), expectedSum, "sumArray method with parameters failed");
    }
}