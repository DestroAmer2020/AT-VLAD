package task8;

public class Task2 {

    // Метод 1: Ініціалізація масиву
    public int[] initializeArray() {
        return new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    }

    // Метод 2: Підрахунок кількості парних чисел
    public int countEvenNumbers(int[] array) {
        int count = 0;
        for (int num : array) {
            if (num % 2 == 0) {
                count++;
            }
        }
        return count;
    }

    // Метод 3: Сума чисел у масиві
    public int sumArray(int[] array) {
        int sum = 0;
        for (int num : array) {
            sum += num;
        }
        return sum;
    }

    public Object countOddNumbers(int[] array) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'countOddNumbers'");
    }
}