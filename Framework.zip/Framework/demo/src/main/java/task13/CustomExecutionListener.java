package task13;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.IExecutionListener;

public class CustomExecutionListener implements IExecutionListener {
    
    private static final Logger logger = Logger.getLogger(CustomExecutionListener.class);
    
    static {
        PropertyConfigurator.configure("log4j.properties");
    }

    @Override
    public void onExecutionStart() {
        logger.info("Execution started");
        // Initialize resources for execution
    }

    @Override
    public void onExecutionFinish() {
        logger.info("Execution finished");
        // Log execution end and cleanup resources
    }
}