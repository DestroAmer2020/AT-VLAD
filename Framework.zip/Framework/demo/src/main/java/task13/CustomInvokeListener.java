package task13;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestResult;

public class CustomInvokeListener implements IInvokedMethodListener {

    private static final Logger logger = Logger.getLogger(CustomInvokeListener.class);
    
    static {
        PropertyConfigurator.configure("log4j.properties");
    }

    @Override
    public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
        logger.info("Before Invocation: " + method.getTestMethod().getMethodName());
        // Log method execution start
    }

    @Override
    public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
        logger.info("After Invocation: " + method.getTestMethod().getMethodName());
        // Log method execution end
    }
}