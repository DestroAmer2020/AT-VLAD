package task13;

import org.apache.log4j.Logger;

import java.io.IOException;

public class VideoRecorder {
    private static final Logger logger = Logger.getLogger(VideoRecorder.class);
    private String videoPath;
    private Process ffmpegProcess;
    private boolean isRecording;

    public VideoRecorder(String videoPath) {
        this.videoPath = videoPath;
        this.isRecording = false;
    }

    // Start recording with FFmpeg
    public void startRecording() {
        if (isRecording) {
            logger.warn("Recording is already in progress.");
            return;
        }

        // Command to start recording with FFmpeg
        // Make sure FFmpeg is installed and added to the system path or provide full path to ffmpeg executable
        String command = "ffmpeg -video_size 1920x1080 -framerate 30 -f x11grab -i :0.0+0,0 " + videoPath;
        
        try {
            ffmpegProcess = new ProcessBuilder(command.split(" ")).start();
            isRecording = true;
            logger.info("Video recording started.");
        } catch (IOException e) {
            logger.error("Error starting video recording: ", e);
        }
    }

    // Stop the recording
    public void stopRecording() {
        if (isRecording && ffmpegProcess != null) {
            ffmpegProcess.destroy();
            isRecording = false;
            logger.info("Video recording stopped.");
        }
    }

    public void onStart() {
        // Initialize WebDriver and other resources (like browser and DB)
        CustomTestListener.logger.info("Test started.");
        // Example: driver = new ChromeDriver(); // Initialize WebDriver
    }

    public void onFinish() {
        CustomTestListener.logger.info("Test finished.");
    
        // You can close any resources (like WebDriver) if needed
        // Example: driver.quit();
    }
}