package task11;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.annotations.AfterMethod;
import io.github.bonigarcia.wdm.WebDriverManager;

public class SignUpTest {
    WebDriver driver;
    SignUpPage signUpPage;
    HomePage homePage;
    SignUpBusiness signUpBusiness;

    @BeforeMethod
    public void setUp() {
        // Set up WebDriver using WebDriverManager
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        driver = new ChromeDriver(options);
        
        // Initialize Page Objects
        signUpPage = new SignUpPage(driver);
        homePage = new HomePage(driver);
        signUpBusiness = new SignUpBusiness(signUpPage, homePage);
    }

    @Test
    public void testSignUp() {
        // Navigate to the sign-up page
        driver.get("https://example.com/signup");

        // Perform sign up and verify login
        signUpBusiness.signUpAndVerify("testuser@example.com", "testuser", "StrongPassword123!");

        // Verify that the user is logged in
        Assert.assertTrue(homePage.isUserLoggedIn(), "User is not logged in.");
    }

    @AfterMethod
    public void tearDown() {
        // Close the browser after the test
        if (driver != null) {
            driver.quit();
        }
    }
}