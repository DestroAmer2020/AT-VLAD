package task12;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;

public class WebElementWrapper {
    
    private WebDriver driver;  // Declare WebDriver

    // Constructor to initialize the WebDriver
    public WebElementWrapper(WebDriver driver) {
        this.driver = driver;
    }

    public String getText(WebElement element) {
        String text = element.getText();
        System.out.println("Text Retrieved: " + text);
        return text;
    }

    public void waitForText(WebElement element, String text) {
        final WebDriverWait wait = new WebDriverWait(driver, 10); // 10 seconds timeout
        try {
            wait.until(ExpectedConditions.textToBePresentInElement(element, text));
            System.out.println("Text '" + text + "' found in the label.");
        } catch (TimeoutException e) {
            System.out.println("Text '" + text + "' not found in the label within the time limit.");
        }
    }

    public boolean verifyLabelExists(WebElement element) {
        try {
            return element.isDisplayed();
        } catch (Exception e) {
            System.out.println("Label does not exist.");
            return false;
        }
    }
}