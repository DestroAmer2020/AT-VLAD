package task11;

public class SignUpBusiness {
    SignUpPage signUpPage;
    HomePage homePage;

    public SignUpBusiness(SignUpPage signUpPage, HomePage homePage) {
        this.signUpPage = signUpPage;
        this.homePage = homePage;
    }

    public void signUpAndVerify(String email, String username, String password) {
        signUpPage.enterEmail(email);
        signUpPage.enterUsername(username);
        signUpPage.enterPassword(password);
        signUpPage.clickSignUp();

        // Wait for home page to load (you can improve this with WebDriverWait)
        try {
            Thread.sleep(2000); // Simulate wait for the page to load
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Verify the user is logged in
        if (homePage.isUserLoggedIn()) {
            System.out.println("Account created and user is logged in.");
        } else {
            System.out.println("Account creation failed.");
        }
    }
}