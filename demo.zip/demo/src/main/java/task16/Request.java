package task16;

public class Request {
    private String endpoint;
    private String payload;

    public Request(String endpoint, String payload) {
        this.endpoint = endpoint;
        this.payload = payload;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public String getPayload() {
        return payload;
    }
}