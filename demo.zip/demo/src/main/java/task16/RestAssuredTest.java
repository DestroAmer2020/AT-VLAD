package task16;

import io.restassured.RestAssured;
import io.restassured.response.ResponseBody;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

public class RestAssuredTest {

    @Test
    public void testGetEndpoint() {
        RestAssured.baseURI = "https://jsonplaceholder.typicode.com"; // Example API

        Response response = new Response(
                given()
                        .get("/posts/1") // Example GET request
                        .statusCode(),
                given()
                        .get("/posts/1")
                        .body().asString()
        );

        assertEquals(response.getStatusCode(), 200, "Status code mismatch");
        assertEquals(response.getBody().contains("userId"), true, "Response body validation failed");
    }

    @Test
    public void testPostEndpoint() {
        RestAssured.baseURI = "https://jsonplaceholder.typicode.com"; // Example API

        Request request = new Request("/posts", "{\"title\":\"foo\",\"body\":\"bar\",\"userId\":1}");
        Response response = new Response(
                given()
                        .header("Content-Type", "application/json")
                        .body(request.getPayload())
                        .post(request.getEndpoint())
                        .statusCode(),
                given()
                        .header("Content-Type", "application/json")
                        .body(request.getPayload())
                        .post(request.getEndpoint())
                        .body().asString()
        );

        assertEquals(response.getStatusCode(), 201, "Status code mismatch");
        assertEquals(response.getBody().contains("foo"), true, "Response body validation failed");
    }
}