package task6;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateCRUD {

    public static void main(String[] args) {
        // Configure Hibernate session factory
        SessionFactory sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Person.class)
                .addAnnotatedClass(Address.class)
                .buildSessionFactory();

        // Create a new session
        Session session = sessionFactory.getCurrentSession();

        try {
            // 1. Create a new Address and Person
            Address address = new Address("234 Elm St", "Boston", "MA");
            Person person = new Person(false, "Jessica", address);

            // Start a transaction
            session.beginTransaction();

            // Save the person (this will also save the address due to cascade)
            session.save(person);

            // Commit the transaction
            session.getTransaction().commit();

            // 2. Retrieve Person based on the ID
            session = sessionFactory.getCurrentSession();
            session.beginTransaction();

            Person retrievedPerson = session.get(Person.class, person.getId());

            System.out.println("Retrieved Person: " + retrievedPerson);

            // 3. Update the Person's name
            retrievedPerson.setName("John Doe");

            // Commit the transaction
            session.getTransaction().commit();

            // 4. Delete the Person
            session = sessionFactory.getCurrentSession();
            session.beginTransaction();

            session.delete(retrievedPerson);

            session.getTransaction().commit();

        } finally {
            sessionFactory.close();
        }
    }
}