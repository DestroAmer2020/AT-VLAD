package main.java.task21;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import javax.imageio.ImageIO;

import task20.By;

import java.awt.*;
import java.awt.image.BufferedImage;

public class CalculatorTest {
    public static void main(String[] args) throws MalformedURLException, InterruptedException {
        // Налаштування Winium
        DesktopOptions options = new DesktopOptions();
        options.setApplicationPath("C:\\Windows\\System32\\calc.exe"); // Шлях до калькулятора Windows

        WiniumDriver driver = new WiniumDriver(new URL("http://localhost:9999"), options);

        // Очікування, щоб додаток відкрився
        Thread.sleep(2000);

        // Введення числа 500
        WebElement five = (WebElement) driver.findElement(By.name("Five"));
        WebElement zero = driver.findElement(By.name("Zero"));
        five.click();
        zero.click();
        zero.click();

        // Натискання кнопки відсотків
        WebElement percent = driver.findElement(By.name("Percent"));
        percent.click();

        // Отримання результату
        WebElement result = driver.findElement(By.id("CalculatorResults"));
        String resultText = result.getAttribute("Name");

        // Перевірка результату
        System.out.println("Результат: " + resultText);
        if (resultText.contains("100")) {
            System.out.println("Тест пройдено успішно!");
        } else {
            System.out.println("Тест провалено!");
        }

        // Збереження скріншоту
        try {
            Robot robot = new Robot();
            Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
            BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
            ImageIO.write(screenFullImage, "png", new File("CalculatorTestResult.png"));
            System.out.println("Скріншот збережено.");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Завершення роботи
        driver.quit();
    }
}