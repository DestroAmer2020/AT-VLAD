package task12;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestScenario {

    @Test
    public void testLabelActions() {
        // Initialize WebDriver
        WebDriver driver = new ChromeDriver();  // Make sure you have the correct driver path set

        // Navigate to the desired page
        driver.get("https://yourwebsite.com");

        // Initialize the SamplePage object with the driver
        SamplePage samplePage = new SamplePage(driver);

        // Check if label exists
        boolean exists = samplePage.verifyLabelExists();
        assert exists : "Label doesn't exist on the page.";

        // Retrieve and verify label text
        String labelText = samplePage.getLabelText();
        assert labelText.equals("Expected Text") : "Label text does not match.";

        // Wait for specific text in the label
        samplePage.waitForLabelText("Expected Text");

        // Close the driver after the test
        driver.quit();
    }
}