package task12;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.WebDriver;

public class SamplePage {

    private WebDriver driver; // Declare WebDriver

    @FindBy(id = "labelId")
    WebElement label;

    // Constructor to initialize the PageFactory elements
    public SamplePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Create an instance of WebElementWrapper
    WebElementWrapper webElementWrapper = new WebElementWrapper(driver);

    // Method to retrieve the text of the label
    public String getLabelText() {
        return webElementWrapper.getText(label);
    }

    // Method to wait for specific text in the label
    public void waitForLabelText(String text) {
        webElementWrapper.waitForText(label, text);
    }

    // Method to verify if the label exists
    public boolean verifyLabelExists() {
        return webElementWrapper.verifyLabelExists(label);
    }
}