package task5;

import java.io.Serializable;

public class Person implements Serializable {
    private boolean isEmployed;
    private String name;
    private Address address;

    // Constructor
    public Person(boolean isEmployed, String name, Address address) {
        this.isEmployed = isEmployed;
        this.name = name;
        this.address = address;
    }

    // Getters and Setters
    public boolean isEmployed() {
        return isEmployed;
    }

    public void setEmployed(boolean employed) {
        isEmployed = employed;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    // Nested Address Class
    public static class Address implements Serializable {
        private String street;
        private String city;
        private String state;

        // Constructor
        public Address(String street, String city, String state) {
            this.street = street;
            this.city = city;
            this.state = state;
        }

        // Getters and Setters
        public String getStreet() {
            return street;
        }

        public void setStreet(String street) {
            this.street = street;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }
    }
}