package task13;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class CustomTestListener implements ITestListener {

    static final Logger logger = Logger.getLogger(CustomTestListener.class);
    @SuppressWarnings("unused")
    private WebDriver driver;
    private VideoRecorder videoRecorder;

    public CustomTestListener() {
        // Initialize VideoRecorder with the path to save the video
        videoRecorder = new VideoRecorder("path/to/save/video_" + System.currentTimeMillis() + ".mp4");
    }

    @Override
    public void onTestStart(ITestResult result) {
        logger.info("Starting test: " + result.getName());

        // Start video recording before the test begins
        videoRecorder.startRecording();
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        logger.info("Test Passed: " + result.getName());

        // Stop video recording on test success
        videoRecorder.stopRecording();
    }

    @Override
    public void onTestFailure(ITestResult result) {
        logger.error("Test Failed: " + result.getName());

        // Stop video recording on test failure
        videoRecorder.stopRecording();

        // Take a screenshot, log the failure, etc.
        // Optionally, save logs and screenshots here as well
        // You can capture a screenshot here as well if needed
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        logger.info("Test Skipped: " + result.getName());
    }
}
