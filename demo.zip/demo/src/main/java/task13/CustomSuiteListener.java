package task13;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.ISuite;
import org.testng.ISuiteListener;

public class CustomSuiteListener implements ISuiteListener {
    
    private static final Logger logger = Logger.getLogger(CustomSuiteListener.class);
    
    static {
        PropertyConfigurator.configure("log4j.properties");
    }

    @Override
    public void onStart(ISuite suite) {
        logger.info("Test Suite Started: " + suite.getName());
        // Set up environment or initialize data for suite
    }

    @Override
    public void onFinish(ISuite suite) {
        logger.info("Test Suite Finished: " + suite.getName());
        // Tear down environment or clean up data created during the test suite execution
    }
}